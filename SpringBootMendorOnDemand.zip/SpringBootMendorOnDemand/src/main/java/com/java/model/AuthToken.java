package com.java.model;

public class AuthToken {

    private String token;
    private String username;
    private String userType;
    private long userId;
    

    public AuthToken(){

    }

    public AuthToken(String token, String username, String userType,long userId){
        this.token = token;
        this.username = username;
        this.userType=userType;
        this.userId=userId;
    }

    public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public AuthToken(String token){
        this.token = token;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}
}
